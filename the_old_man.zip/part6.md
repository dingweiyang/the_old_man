## part6

"Tell me about the baseball," the boy asked him. "In the American League it is the Yankees as I said," the old man said happily. "They lost today," the boy told him. "That means nothing. The great DiMaggio is himself again." "They have other men on the team." "Naturally. But he makes the difference. In the other league, between Brooklyn and Philadelphia I must take Brooklyn. But then I think of Dick Sisler and those great drives in the old park." "There was nothing ever like them. He hits the longest ball I have ever seen."
> 余：“把棒球的消息告诉我。”男孩央求他。“我说过的，美联队还是北美队胜。”老人得意地说。“今天他们可输了。”男孩告诉他。“那不算什么。伟大的第马吉奥重振声威了。”“他们队里换了人。”“自然了。可是没他就不同了。另一组，布鲁克林对费拉德尔菲亚，我还是喜欢布鲁克林。这么说，我又想起了狄克·席思勒和老公园里那种精彩的猛球。”“简直天下无敌。我一辈子看过的球算他打得最远。”
> 
> 张：「你讲棒球的事给我听。」孩子请求他。「在美国联赛里就推洋基队了，我早就说过，」老人快乐地说。「他们今天输了，」孩子告诉他。「那不算什么。伟大的狄玛奇奥又恢复了往日的雄风。」「他们这一队里也还有别人。」「那自然啰。可是有了他就两样了。在另外那个联赛里，在布鲁克林和费城两队里面，我还是宁愿要布鲁克林队。可是我又想起狄克西斯勒，在老球场里那样有力地一记记打过去。」「从来没有人打过像他们那样的球。我看见过的人里是他打得最远了。」

"Do you remember when he used to come to the Terrace? I wanted to take him fishing but I was too timid to ask him. Then I asked you to ask him and you were too timid." "I know. It was a great mistake. He might have gone with us. Then we would have that for all of our lives." "I would like to take the great DiMaggio fishing," the old man said. "They say his father was a fisherman. Maybe he was as poor as we are and would understand." "The great Sisler's father was never poor and he, the father, was playing in the Big Leagues when he was my age."
> 余：“你还记得他以前常来平台吗？我真想带他去钓鱼，可是又不敢请他。后来又叫你去请他，你也不敢。”“我记得。那是个大错。他也许真会跟我们去。那真够我们乐一辈子了。”“我真想带伟大的第马吉奥去钓鱼，”老人说，“他们说他的父亲也做过渔夫。恐怕他以前也像我们这么穷，懂得这一套的。”“伟大的席思勒的父亲一点也不穷，他父亲像我这么大就在大球队里打球了。”
> 
> 张：「你可记得那时候他常常到露台酒店来？我想要带他去打鱼，可是我胆子太小，没敢问他。后来我叫你问他，你也胆子太小。」「我知道。我们真不该那样。他也说不定会跟我们去的。那就够我们快乐一辈子的。」「我很想带伟大的狄玛奇奥去打鱼。」老人说。「他们说他父亲是一个渔夫。也许他从前也跟我们一样穷，那他就会懂得的。」「伟大的西斯勒的父亲从来没穷过。他(那父亲)像我这样年纪的时候就在大联赛里打球了。」

"When I was your age I was before the mast on a square rigged ship that ran to Africa and I have seen lions on the beaches in the evening." "I know. You told me." "Should we talk about Africa or about baseball?" "Baseball I think," the boy said. "Tell me about the great John J. McGraw." He said Jota for J. "He used to come to the Terrace sometimes too in the older days. But he was rough and harsh-spoken and difficult when he was drinking. His mind was on horses as well as baseball.At least he carried lists of horses at all times in his pocket and frequently spoke the names of horses on the telephone." 
> 余：“我像你这么大的时候，正在去非洲的一条老式帆船上做水手，到黄昏还看见岸上的狮子。”“我晓得。你对我说过的。”“我们谈非洲呢，还是谈棒球？”“我想还是谈棒球吧，”男孩说，“谈谈伟大的约翰·杰·马格洛吧。”他说“杰”是“荷塔”。“早年他有时也爱到平台上来。可是他蛮得很，说话又粗，喝起酒来更难应付。他爱棒球，也爱玩马。至少他袋子里总是带着各式各样赛马的名单，打电话的时候，也老是提起马的名字。”
> 
> 张：「我像你这样年纪的时候，在一条专跑非洲的方帆的船上当水手，我晚上在海岸上看见过狮子。」「我知道，你告诉我的。」「我们谈非洲还是谈棒球？」「我想还是棒球，」孩子说。「你讲给我听伟大的约翰杰麦格劳的事。」他把「杰」说成「乔塔」。
「他从前有时候也到露台酒店来，但是他喝醉了就粗野起来，说话很凶，脾气坏。他心心念念除了棒球还有赛马。至少他是一天到晚口袋里都装着马的名单，并且常常在电话上说马的名字。」

"He was a great manager," the boy said. "My father thinks he was the greatest." "Because he came here the most times," the old man said. "If Durocher had continued to come here each year your father would think him the greatest manager." "Who is the greatest manager, really, Luque or Mike Gonzalez?" "I think they are equal. "And the best fisherman is you." " No. I know others better."
> 余：“他是了不起的经理人，”男孩说，“我父亲觉得他最了不起。”“因为他最常来这儿的关系，”老人说，“要是杜洛舍年年都来的话，你父亲又会觉得他是最了不起的经理人了。”“到底谁最了不起呢，吕克，还是迈克·垄沙雷？”“我看他们不相上下。”“可是最能干的渔夫是你。”“才不是。我晓得有好些人比我能干。”“哪里话，”男孩说，“能干的渔夫很多，了不起的也有几个。可是像你这样的，只有一个。”
> 
> 张：「他是个伟大的经理，」孩子说。「我父亲认为他是最伟大的一个。」「因为他到这里来的次数最多，」老人说。「假使杜洛歇继续着每年到这里来，你父母一定认为他是伟大的经理。」「谁是真正的最伟大的经理呢，鲁克还是迈克冈沙列兹？」「我觉得他们俩不分上下。」「最好的渔夫是你了。」「不。我知道有别人比我好的。」

"Que va," the boy said. "There are many good fishermen and some great ones. But there is only you." "Thank you. You make me happy. I hope no fish will come along so great that he will prove us wrong. "There is no such fish if you are still strong as you say," "I may not be as strong as I think," the old man said. "But I know many tricks and I have resolution." "You ought to go to bed now so that you will be fresh in the morning. I will take the things back to the Terrace."
> 余：
> 
> 张：