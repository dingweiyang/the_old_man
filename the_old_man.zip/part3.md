## part3

 "Tomorrow is going to be a good day with this current," he said. "Where are you going?" the boy asked.
> 余：“湾流不变的话，明天准是个好晴天。”他说。“你去哪儿？”男孩问他。
>
> 张：「明天一定收获好，有这潮水，」他说。「你预备到那里去？」孩子问。

"Far out to come in when the wind shifts. I want to be out before it is light." 
> 余：“去远海，风向转变就回来，我想在天亮之前就出海。”
> 
> 张：「老远的，等风转了向再回来。我要天亮前就出去。」

"I'll try to get him to work far out," the boy said. "Then if you hook something truly big we can come to your aid." 
> 余：“我可以想法引他到远海去打鱼，”男孩说，“这样一来，要是你真的钓到条大的，我们就能来帮你的忙。”
> 
> 张：「我来试着叫他也到远处去打鱼，」孩子说，「那么假使你钓着一条真正大的，我们可以帮你的忙。」

"He does not like to work too far out." "No," the boy said. "But I will see something that he cannot see such as a bird working and get him to come out after dolphin." "Are his eyes that bad?" "He is almost blind." "It is strange," the old man said. "He never went turtle-ing. That is what kills the eyes."
> 余：“他不喜欢出海太远。”“是嘛，”男孩说，“可是他看不见的东西我看得见，譬如有鸟儿低飞寻鱼；我还可以引他出海去追鲯鳅。”“他的眼睛那么坏吗？”“他差点瞎了。”“那奇怪了，”老人说，“他从来没捉过龟。捉龟最伤眼睛。”
> 
> 张：「他不喜欢到太远的地方去打鱼。」「是的，」孩子说。「但是有些东西他看不见的，我看得见，譬如有一只鸟在那里捉鱼，那我就可以叫他去钓鲯鳅。」「他的眼睛这样坏？」「他差不多瞎子。」「这很奇怪。他从来也没有去捕龟，那最伤眼睛了。」

"But you went turtle-ing for years off the Mosquito Coast and your eyes are good." "I am a strange old man." "But are you strong enough now for a truly big fish?" "I think so. And there are many tricks." 
> 余：“可是你在蚊子海岸捉了几年的龟，眼睛还是好好的。”“我是个老精灵。”“不过，你现在真有气力对付真正的大鱼吗？”“我想是有的。而且诡计多端。”
> 
> 张：「可是你在蚊子海岸那边捕了许多年海龟，你的眼睛还是好的。」「我是个奇怪的老头子。」「可以你现在对付一条真正的大鱼，力气够不够？」「我想够的。而且还有许多诀窍。」

"Let us take the stuff home," the boy said. "So I can get the cast net and go after the sardines." They picked up the gear from the boat. The old man carried the mast on his shoulder and the boy carried the wooden box with the coiled, hard-braided brown lines, the gaff and the harpoon with its shaft.
> 余：“我们把这些东西拿回去吧，”男孩说，“我还要拿网去捉沙丁鱼呢。”他们自船上拿起船具。老人掮着船桅，男孩拿着满箱结实的褐色绳圈，加上鱼钩和带柄的鱼叉。
> 
> 张：「我们来把东西拿回去吧，」孩子说。「我好去拿网，再去弄沙汀鱼。」他们把用具从船上拾起来。老人扛着桅杆，孩子拿着木箱，箱子里装着一卷卷编得硬硬的棕色钓丝，还有鱼钩，鱼叉，和鱼叉的柄。

The box with the baits was under the stern of the skiff along with the club that was used to subdue the big fish when they were brought alongside. No one would steal from the old man but it was better to take the sail and the heavy lines home as the dew was bad for them and, though he was quite sure no local people would steal from him, the old man thought that a gaff and a harpoon were needless temptations to leave in a boat. 
> 余：盛着鱼饵的箱子和木棍一起放在小舟的船尾下面；每当大鱼拖到了船边，老人就用那根棍子来制服它。没有人会偷老人的东西，不过最好还是把布帆和粗绳带回去，因为它们怕受露水；再加，他虽然相信当地的人不会偷他的东西，却担心把鱼钩鱼叉留在船上毕竟是不必要的诱惑。
> 
> 张：装饵的盒子搁在小船的船尾，和木棒放在一起，木棒是用来制服大鱼的，把那鱼已经拖到船边的时候，用木棒打它。没有人会偷老人的东西，但是帆和粗钓丝还是拿回家去的好，因为怕露水，而且，虽然他很确定本地人没有一个会偷他的东西，老人总觉得不必把鱼钩和鱼叉丢在船上，引诱人家。

They walked up the road together to the old man's shack and went in through its open door.The old man leaned the mast with its wrapped sail against the wall and the boy put the box and the other gear beside it. The mast was nearly as long as the one room of the shack. The shack was made of the tough budshields of the royal palm which are called guano and in it there was a bed, a table, one chair and a place on the dirt floor to cook with charcoal. On the brown walls of the flattened, overlapping leaves of the sturdy fibered guano there was a picture in color of the Sacred Heart of Jesus and another of the Virgin of Cobre.
> 余：他们一同走到老人的小屋，从敞开的门口进去。老人把卷着布帆的船桅靠在墙上，男孩就把箱子和别的渔具放在桅边。那船桅几乎和小屋仅有的一个房间一样长。小屋用一种叫做“瓜诺”的白干棕护心韧皮盖成，内有一床、一桌、一椅，污秽的地板上还有一处地方，供炭炊之用。纤维结实的瓜诺那扁平而交叠的叶子，编成褐色的墙壁，壁上挂着圣心耶稣的彩色图像，另有一张是科伯的圣母像。
> 
> 张：他们一同沿着路走上去，来到老人的小屋里，门开着，他们走进去。老人把那裹着布帆的桅杆倚在墙上，孩子把箱子和其它的工具搁在旁边。桅杆差不多有小屋里唯一的这间房一样长。小屋是用一种棕树结实的嫩叶造成的。小屋里有一张床，一张桌子，一张椅子，泥地上有一个地方可以用炭来烧饭。纤维坚强的棕树叶子，压扁摊平了，组成棕色的墙，墙上挂着一张基督圣心的彩色画，还有一张是考伯的圣处女。

These were relics of his wife. Once there had been a tinted photograph of his wife on the wall but he had taken it down because it made him too lonely to see it and it was on the shelf in the corner under his clean shirt. 
> 余：这些都是他妻子的遗物。往日壁上曾挂着他妻子的彩色照片，可是他已经将它取下，因为看着照片使他感觉过分的寂寞。如今那照片搁在墙角的架子上，压在他干净的衬衫下面。
> 
> 张：这些都是他的妻子的遗物。从前有一张他的妻的着色照片挂在墙上，但是他把它拿下来了，因为看着它使他太寂寞，现在它在墙角的木架上，在他的干净衬衫底下。
