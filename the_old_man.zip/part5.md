## part5

The boy left him there and when he came back the old man was still asleep. "Wake up old man," the boy said and put his hand on one of the old man's knees. The old man opened his eyes and for a moment he was coming back from a long way away. Then he smiled. "What have you got?" he asked. "Supper," said the boy. "We're going to have supper." "I'm not very hungry." "Come on and eat. You can't fish and not eat. "I have," the old man said getting up and taking the newspaper and folding it. Then he started to fold the blanket.
> 余：男孩走时，他坐在那儿，回来时他还在熟睡。“醒一醒，老头子。”男孩说着，用手按住老人的一边膝盖。老人睁开眼睛；刹那间，他从远方清醒回来。接着他微笑起来。“你弄到什么东西？”他问道。“晚饭，”男孩说，“我们就要吃晚饭了。”“我不大饿。”“来吃吧。你不能钓鱼不吃东西的。”“我试过的。”老人说着，坐了起来，拿起报纸折好。接着又开始折毯子。
> 
> 张：孩子把他留在那里，他再回来的时候，老人还在睡着。「老头子醒醒吧，」孩子说，他把一只手放在老人的膝盖上。老人张开眼睛，在那一剎那间，他是从很远的地方回来。然后他微笑了。「你手里拿着什么？」他问。「晚饭，」孩子说。「我们要吃晚饭了。」「我不大饿。」「来吃吧。你不能打鱼而不吃饭。」「我试过了。」老人说，一面站起来，拿起报纸把它折迭起来，然后他开始来迭毯子。

"Keep the blanket around you," the boy said. "You'll not fish without eating while I'm alive." "Then live a long time and take care of yourself," the old man said, "What are we eating?" "Black beans and rice, fried bananas, and some stew." The boy had brought them in a two-decker metal container from the Terrace. The two sets of knives and forks and spoons were in his pocket with a paper napkin wrapped around each set. "Who gave this to you?" "Martin. The owner." "I must thank him."
> 余：“把毯子裹在身上吧，”男孩说，“只要我一天还活着，你总不会捉鱼时没东西吃。”“那么就祝你长寿，自己保重，”老人说，“我们吃什么？”“乌豆、米、炸香蕉，还有些炖肉。”男孩把这些食品盛在一个双层的金属盒子里，从平台上带来。他袋里装了两副刀叉和汤匙，每副都用纸做的餐巾包好。“谁给你的？”“马丁老板。”“我要谢谢他。”
> 
> 张：「你还是把毯子围在身上吧，」孩子说。「只要我活在世上一天，决不让你打鱼不吃饭。」「那么你活得长长的，好好当心你自己，」老人说。「我们吃什么？」「黑豆和米饭，煎香蕉。还有点炖肉。」孩子从露台酒店，把饭菜装在一个双层的金属品食盒里带了来。两副刀叉和匙子装在他口袋里，每一副外面裹着一张纸巾。「这是谁给你的？」「马丁。那老板。」「我得要谢谢他。」

"I thanked him already," the boy said. "You don't need to thank him." "I'll give him the belly meat of a big fish," the old man said. "Has he done this for us more than once?" "I think so." "I must give him something more than the belly meat then. He is very thoughtful for us." "He sent two beers." "I like the beer in cans best." "I know. But this is in bottles, Hatuey beer, and I take back the bottles." "That's very kind of you," the old man said. "Should we eat?"
> 余：“我已经谢过他，”男孩说，“你不必再谢了。”“我要送他大鱼肚皮那儿的肉，”老人说，“他这样招待我们，不止一次了吧？”“我想不止了。”“这么说，除了肚皮那儿的肉，我还得送他些别的东西。他真是够体贴的。”“他送来两份啤酒。”“我最喜欢罐装的啤酒。”“我晓得。可是这回是瓶装的，哈退啤酒；我得把瓶子拿回去。”“多谢你了，”老人说，“我们可以吃了吗？”
> 
> 张：「我已经谢过他了，」孩子说。「你用不着去谢他。」「我下回把一条大鱼的肚肉给他，」老人说。「他给我们东西可是已经不止一次了？」「我想是的。」「那我除了肚肉一定还要多给他一点。他对我们非常体贴。」「他送了两份啤酒来。」「我最喜欢听装的啤酒。」「我知道，但这是瓶装的，哈杜依啤酒，我把瓶送回去。」「你真好，」老人说。「我们该吃了吧？」


"I've been asking you to," the boy told him gently. "I have not wished to open the container until you were ready." "I'm ready now," the old man said. "I only needed time to wash." Where did you wash? The boy thought. The village water supply was two streets down the road. I must have water here for him, the boy thought, and soap and a good towel. Why am I so thoughtless? I must get him another shirt and a jacket for the winter and some sort of shoes and another blanket. "Your stew is excellent," 
> 余：“我就是在问你呢，”男孩温和地对他说，“你还没有准备好，我总不会开盒子。”“我好了，”老人说，“我就是洗手花时间。”你去哪儿洗呢？男孩想道。村上的水源要走两条街。我应该在这儿为他准备点水，还有肥皂和面巾，男孩想道。我怎么就这样粗心呢？我应该再为他弄一件衬衫、一件过冬的外套，不管什么鞋子都得弄一双，再弄条毯子。“炖肉真好吃。”老人说。
> 
> 张：「我刚才已经在叫你吃了，」孩子柔和地告诉他。「我想等你预备好了再把食盒打开。」「我现在预备好了，」老人说。「我只需要一点时候洗刷洗刷。」你在那里洗呢？孩子想。村庄里的蓄水，沿着这条路走下去要隔两条街。我得要给他弄点水在这里，孩子想，还要肥皂和一条好毛巾。我为什么这样粗心？我得要给他另外弄件衬衫，还在一件外衣冬天穿，还要一双随便什么鞋子，和另外一条毯子。「你这炖肉真不错，」老人说。